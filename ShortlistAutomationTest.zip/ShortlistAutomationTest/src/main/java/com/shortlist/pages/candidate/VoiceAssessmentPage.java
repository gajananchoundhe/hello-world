package com.shortlist.pages.candidate;

public class VoiceAssessmentPage {

}
