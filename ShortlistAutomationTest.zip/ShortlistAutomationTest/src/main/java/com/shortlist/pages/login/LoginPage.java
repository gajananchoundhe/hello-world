package com.shortlist.pages.login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.testng.Assert;

import com.shortlist.automationtest.utility.GenerateTestData;
import com.shortlist.automationtest.utility.Log;
import com.shortlist.automationtest.utility.SeleniumFactory;



public class LoginPage {

	 WebDriver driver = null;

	    String emailAddress="akshay.pandey@gmail.com";
	    String password_="Admin@123";

	    @FindBy(how = How.NAME, using = "userName")
	    private WebElement usernameInputField;

	    @FindBy(how = How.NAME, using = "password")
	    private WebElement passwordInputField;

	    @FindBy(how = How.XPATH, using = "//button/span[text()=\" LOG IN \"]")
	    private WebElement loginButton;


	    //Sign up Page elements
	    @FindBy(how = How.XPATH, using = "//div[@class=\"signup-toggle ng-star-inserted\"]/button")
	    private WebElement signUpHereButton;

	    @FindBy(how = How.XPATH, using = "//h2[text()=\"Candidate Sign Up\"]")
	    private WebElement signUpTitleOnPage;

	    @FindBy(how = How.NAME, using = "fullName")
	    private WebElement fullNameField;

	    @FindBy(how = How.NAME, using = "userName")
	    private WebElement emailField;

	    @FindBy(how = How.NAME, using = "password")
	    private WebElement passwordField;

	    @FindBy(how = How.XPATH, using = "//button[@type=\"submit\"]")
	    private WebElement signUpSubmitButton;


	    public LoginPage()  // Constructor to initialize Web elements using Page factory
	    {
	        driver = SeleniumFactory.getWebDriverInstance();
	        PageFactory.initElements(new AjaxElementLocatorFactory(driver, 60), this);
	    }


	    public void login() {

	        Log.getLogger().info("Username: " + emailAddress);
	        Log.getLogger().info("Password: " + password_);
	        usernameInputField.sendKeys(emailAddress);
	        passwordInputField.sendKeys(password_);
	        Log.getLogger().info("Entered username and password");
	        loginButton.click();
	        SeleniumFactory.waitForSecond(5);
	        String pageURL = driver.getCurrentUrl();

	        Assert.assertEquals(pageURL, "https://qa.shortlist.net/webportal/#/dashboard/all-jobs");


	    }



	    public void fillSignUpFormAndSubmit()
	    {
	        signUpHereButton.click();
	        String signUpPageHeadingText=signUpTitleOnPage.getText();
	        Log.getLogger().info("Title on SignUp Page :"+ signUpPageHeadingText);
	        Assert.assertEquals(signUpPageHeadingText,"Candidate Sign Up");

	        emailAddress=GenerateTestData.getGeneratedEmailAddress();
	        Log.getLogger().info("Generated Email Address :"+emailAddress);
	        fullNameField.sendKeys("Gajanan Choundhe");
	        emailField.sendKeys(emailAddress);
	        passwordInputField.sendKeys(password_);
	        signUpSubmitButton.click();

	        SeleniumFactory.waitForSecond(4);

	        if(driver.getPageSource().contains("You’ve registered with that email already."))
	        {
	            Log.getLogger().info("You’ve registered with that email already");
	            emailAddress=GenerateTestData.getGeneratedEmailAddress();
	            Log.getLogger().info("Again generated Email Address :"+emailAddress);
	            emailField.clear();
	            emailField.sendKeys(emailAddress);
	           signUpSubmitButton.click();
	        }

	        SeleniumFactory.waitForSecond(4);
	        String pageURL = driver.getCurrentUrl();
	        Assert.assertEquals(pageURL, "https://qa.shortlist.net/webportal/#/dashboard/all-jobs");
	        Log.getLogger().info("You’ve sign up successfully");


	    }

}
