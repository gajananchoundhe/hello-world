package com.shortlist.pages.candidate;

public class PsychomatricAssessmentPage {

}
