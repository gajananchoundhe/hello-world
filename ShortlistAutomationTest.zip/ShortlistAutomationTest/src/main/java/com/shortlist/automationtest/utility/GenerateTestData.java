package com.shortlist.automationtest.utility;

import java.util.Random;

public class GenerateTestData {

	public static String getGeneratedEmailAddress() {
		Random random = new Random();
		int randomeNum = random.nextInt(1550);
		String emailAddress = "gajanan.choundhe" + randomeNum + "@gmail.com";
		return emailAddress;

	}
}
