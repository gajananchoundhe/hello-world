package com.shortlist.automationtest.utility;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.github.bonigarcia.wdm.WebDriverManager;

public class SeleniumFactory {

	public static WebDriver driver = null;

	public static void setUpBrowser(String browserName) {

		// invoke logger
		Log.invokeLogger();

		try {

			runTestOnLocalMachine(browserName, false);

		} catch (Exception ex) {
			Log.getLogger().error("Failed to launch the browser");
			Log.getLogger().error(ex.getMessage());

		}

	}

	public static void closeBrowser() {
		if (driver != null) {
			// driver.quit();
		}
	}

	public static WebDriver getWebDriverInstance() {
		return driver;
	}

	public static void openWebSiteInBrowser() {
		String webSiteURL = "https://qa.shortlist.net/webportal/#/login";
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Log.getLogger().info("Implicit wait applied on the driver for 10 seconds");
		driver.get(webSiteURL);

		waitForPageLoad();

		Boolean isAgreePopUpDisplayed = isElementExist(By.linkText("AGREE"));
		if (isAgreePopUpDisplayed) {
			driver.findElement(By.linkText("AGREE")).click();
		}

		Log.getLogger().info("Web site launched: " + driver.getCurrentUrl());
	}

	public static void scrollToElement(WebElement element) {

		if (element != null) {
			JavascriptExecutor je = (JavascriptExecutor) driver;
			je.executeScript("arguments[0].scrollIntoView(true);", element);
		} else {
			Log.getLogger().info("Element not found");
		}
	}

	public static void waitForSecond(int seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (Exception e) {
			Log.getLogger().info(e.getMessage());
		}
	}

	public static Boolean isElementExist(WebElement element) {

		Boolean isExist = true;

		try {
			getWebDriverWaitInstance().until(ExpectedConditions.elementToBeClickable(element));
		} catch (Exception e) {
			isExist = false;

			Log.getLogger().info("Element not found: " + element);
			Log.getLogger().error(e.getMessage());
		}

		return isExist;
	}

	public static Boolean isElementExist(By locator) {

		Boolean isExist = true;

		try {
			getWebDriverWaitInstance().until(ExpectedConditions.visibilityOfElementLocated(locator));
		} catch (Exception e) {
			isExist = false;

			Log.getLogger().info("Element not found: " + locator);
			Log.getLogger().error(e.getMessage());
		}

		return isExist;
	}

	public static WebDriverWait getWebDriverWaitInstance() {

		WebDriverWait wait = new WebDriverWait(driver, 15, 5);
		return wait;
	}

	public static void waitForPageLoad() {
		driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
	}

	public static void getPageLoadStatus() {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		String pageLoadStatus = (String) js.executeScript("return document.readyState");
		Log.getLogger().info("Page Load Status:" + pageLoadStatus);

	}

	/**
	 * Run test on local machine
	 * 
	 * @param browserName, runTestOnHeadlessBrowser
	 */
	public static void runTestOnLocalMachine(String browserName, Boolean runTestOnHeadlessBrowser) {
		if (driver == null) {

			if (browserName.equalsIgnoreCase("chrome")) {
				WebDriverManager.chromedriver().setup();
				if (runTestOnHeadlessBrowser) {
					ChromeOptions options = new ChromeOptions();
					options.setHeadless(true);
					driver = new ChromeDriver(options);
					Log.getLogger().info("Test will start on chrome headless browser");

				} else {
					driver = new ChromeDriver();
					Log.getLogger().info("Test will start on chrome browser");
				}

			} else if (browserName.equalsIgnoreCase("firefox")) {
				WebDriverManager.chromedriver().setup();
				if (runTestOnHeadlessBrowser) {
					FirefoxOptions options = new FirefoxOptions();
					options.setHeadless(true);
					driver = new FirefoxDriver(options);
					Log.getLogger().info("Test will start on firefox headless browser");

				} else {
					driver = new FirefoxDriver();
					Log.getLogger().info("Test will start on firefox browser");
				}

			} else {

				Log.getLogger().info("browser not found ");
			}

			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
		}
	}

	public static void runTestOnRemoteMachine() {
		String USERNAME = "gajananchoundhe1";
		String AUTOMATE_KEY = "QKGqjaAP9vS8Wz4GjyKs";
		String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";

		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("browser", "Chrome");
		caps.setCapability("browser_version", "75.0");
		caps.setCapability("os", "Windows");
		caps.setCapability("os_version", "10");
		caps.setCapability("resolution", "1024x768");
		caps.setCapability("name", "Sortlist.com Test");
		try {
			driver = new RemoteWebDriver(new URL(URL), caps);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	public static void pressEscapeKey() {

		waitForSecond(5);
		Robot robot;
		try {
			robot = new Robot();
			robot.keyPress(KeyEvent.VK_ESCAPE);
			robot.keyRelease(KeyEvent.VK_ESCAPE);
		} catch (AWTException e) {

			e.printStackTrace();
		}

	}

	public static void takeScreenshot() {

		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");

		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			String reportDirectory = new File(System.getProperty("user.dir")).getAbsolutePath() + "/src/test/java/";
			File destFile = new File(
					reportDirectory + "/screenshots/" + "_" + formater.format(calendar.getTime()) + ".png");

			FileUtils.copyFile(scrFile, destFile);

		} catch (Exception e) {
			Log.getLogger().error(e.getMessage());
		}

	}

	public static boolean clickOnElement(By locator) {
		try {
			isElementExist(locator);
			Log.getLogger().info("Clicking on element :" + locator);
			getWebDriverWaitInstance().until(ExpectedConditions.elementToBeClickable(locator));
			WebElement element = driver.findElement(locator);
			element.click();
			Log.getLogger().info("Clicked on element :" + locator);
			return true;
		} catch (Exception e) {
			Log.getLogger().info("Not click on element :" + locator);
			Log.getLogger().error("Error :" + e.getMessage());
			return false;
		}
	}

	public static void sendInput(By locator, String input) {

		isElementExist(locator);
		Log.getLogger().info("Entering data to element : " + locator);
		driver.findElement(locator).sendKeys(input);
		Log.getLogger().info("Data entered : " + locator + " " + input);
	}

	public static void scrollVertical() {

		JavascriptExecutor js = ((JavascriptExecutor) driver);
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Log.getLogger().info("Scrolled vertically down page");
	}

	public void getSystemInfo() {

		Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
		String browserName = cap.getBrowserName().toLowerCase();
		String browserVersion = cap.getVersion();
		String sysUserName = System.getProperty("user.name");
		String javaVersion = System.getProperty("java.version");
		String ipAddress = "";

		try {
			ipAddress = InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}

		Log.getLogger().info("user.name: " + sysUserName);
		Log.getLogger().info("java.version: " + javaVersion);
		Log.getLogger().info("BrowserName: " + browserName);
		Log.getLogger().info("Browser version: " + browserVersion);
		Log.getLogger().info("IP Address: " + ipAddress);
	}

	public void getBrowserConsoleLog() {

		waitForSecond(10);

		LogEntries logEntries = driver.manage().logs().get(LogType.BROWSER);
		Log.getLogger().info("Browser Console Log");
		Log.getLogger().info("Total console Log error: " + logEntries.getAll().size());

		for (LogEntry entry : logEntries) {
			Log.getLogger().info(new Date(entry.getTimestamp()) + " " + entry.toString() + " \n");

			Log.getLogger().info("entry.getLevel(): " + entry.getLevel());
			Log.getLogger().info("entry.getMessage(): " + entry.getMessage());
			Log.getLogger().info("entry.toString(): " + entry.toString());
		}

	}

}
