package com.shortlist.test.login;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.shortlist.automationtest.utility.SeleniumFactory;
import com.shortlist.pages.login.LoginPage;



public class LoginTest {

	 LoginPage signUp;

	    @BeforeClass
	    public void beforeClass() {
	        signUp = new LoginPage();

	    }

	    @BeforeSuite
	    @Parameters({"browserName"})
	    public void startTest(String browserName) {

	        SeleniumFactory.setUpBrowser(browserName);
	        SeleniumFactory.openWebSiteInBrowser();
	    }

	    @Test(priority = 1,groups={"SignUp"}, enabled = false)
	    public void verifySignUpTest()
	    {
	        signUp.fillSignUpFormAndSubmit();
	    }


	    
	    @Test(priority = 2,groups={"SignUp"} )
	    public void verifyLogin() {
	        signUp.login();
	    }


	    @AfterSuite
	    public void closeTest()
	    {
	    	SeleniumFactory.closeBrowser();
	    }

	
}
