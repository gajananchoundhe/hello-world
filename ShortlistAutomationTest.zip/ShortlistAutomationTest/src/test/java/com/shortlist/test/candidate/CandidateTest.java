package com.shortlist.test.candidate;

public class CandidateTest {

}
